package puzzle.game;

import javax.swing.JFrame;

public class PuzzleGame
{
    public static void main ( final String[] args )
    {
        // TODO code application logic here
        LoginFrame.setDefaultLookAndFeelDecorated ( true );

        LoginFrame frame = new LoginFrame();
        frame.setTitle ( "Login Page" );
        frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
        frame.setVisible ( true );
    }
}
