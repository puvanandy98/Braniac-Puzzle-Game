package com.example.puzzlegame;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class PuzzlesArrayAdapter extends ArrayAdapter<String>
{
    private final Context context;
    private final String[] values;

    public PuzzlesArrayAdapter(final Context context, final String[] values)
    {
        super(context, -1, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(final int position, final View convertView, final ViewGroup parent)
    {
        final LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View rowView = inflater.inflate(R.layout.layout_puzzles, parent, false);

        final TextView txtTitle = rowView.findViewById(R.id.txtTitle);
        final ImageView imgPuzzle = rowView.findViewById(R.id.imgPuzzle);
        final TextView txtDescription = rowView.findViewById(R.id.txtDescription);

        String[] fields = values[position].split("`");

        txtTitle.setText(fields[0]);

        long oidImage = Long.parseLong(fields[1]);
        imgPuzzle.setImageBitmap(GlobalData.hashOidPuzzleImage.get(oidImage));

        txtDescription.setText(fields[2]);

        return rowView;
    }
}
