package com.example.puzzlegame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener
{
    private ListView lstPuzzles;
    private PuzzlesArrayAdapter adapter;
    private ArrayList<Integer> alPuzzleIDs = new ArrayList<>();
    private ArrayList<String> alPuzzleTitles = new ArrayList<>();
    private ArrayList<Long> alOIDPuzzleImages = new ArrayList<>();
    private ArrayList<String> alPuzzleDescriptions = new ArrayList<>();
    private ArrayList<String> alPuzzles = new ArrayList<>();

    private Button btnViewScoreHistory, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lstPuzzles = findViewById(R.id.lstPuzzles);

        lstPuzzles.setOnItemClickListener(this);

        btnViewScoreHistory = findViewById(R.id.btnViewScoreHistory);
        btnLogout = findViewById(R.id.btnLogout);

        btnViewScoreHistory.setOnClickListener(this);
        btnLogout.setOnClickListener(this);

        new LoadPuzzlesTask().execute();
    }

    @Override
    public void onClick(View view)
    {
        Intent intent;

        switch (view.getId())
        {
            case R.id.btnViewScoreHistory:
                intent = new Intent ( this, ViewScoreHistoryActivity.class );
                startActivity ( intent );
                break;

            case R.id.btnLogout:
                finish();
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id)
    {
        final int puzzleID = alPuzzleIDs.get ( position );
        final String puzzleTitle = alPuzzleTitles.get ( position );
        final long oidPuzzleImage = alOIDPuzzleImages.get ( position );
        final String puzzleDescription = alPuzzleDescriptions.get ( position );

        final Intent intent = new Intent ( this, GameActivity.class );

        intent.putExtra ( "puzzleID", puzzleID );
        intent.putExtra ( "puzzleTitle", puzzleTitle );
        intent.putExtra ( "oidPuzzleImage", oidPuzzleImage );
        intent.putExtra ( "puzzleDescription", puzzleDescription );

        startActivity ( intent );
    }

    private class LoadPuzzlesTask extends AsyncTask<Void, Void, String>
    {
        @Override
        protected String doInBackground ( Void... params )
        {
            Database.InitDatabase();

            String retval;

            try
            {
                Database.OpenDatabase();

                PreparedStatement ps = Database.GetPreparedStatement("SELECT \"Puzzle ID\",\"Title\",\"Image\",\"Description\" FROM \"Puzzles\" ORDER BY \"Title\" ASC");

                ResultSet rs = ps.executeQuery();

                GlobalData.hashOidPuzzleImage.clear();
                alPuzzleIDs.clear();
                alPuzzleTitles.clear();
                alOIDPuzzleImages.clear();
                alPuzzleDescriptions.clear();
                alPuzzles.clear();

                while (rs.next())
                {
                    final int puzzleID = rs.getInt ( 1 );
                    final String title = rs.getString ( 2 );
                    final long oidImage = rs.getLong ( 3 );
                    final String description = rs.getString ( 4 );

                    GlobalData.hashOidPuzzleImage.put(oidImage, Database.LoadImage(oidImage));
                    alPuzzleIDs.add(puzzleID);
                    alPuzzleTitles.add(title);
                    alOIDPuzzleImages.add(oidImage);
                    alPuzzleDescriptions.add(description);
                    alPuzzles.add(title + "`" + oidImage + "`" + description);
                }

                rs.close();
                ps.close();

                Database.CloseDatabase();

                retval = "Success";
            }
            catch ( SQLException e )
            {
                e.printStackTrace();
                retval = e.toString();
            }

            return retval;
        }

        @Override
        protected void onPostExecute ( String value )
        {
            if (value.equals("Success"))
            {
                String[] values = alPuzzles.toArray(new String[alPuzzles.size()]);
                adapter = new PuzzlesArrayAdapter(MainActivity.this, values);
                lstPuzzles.setAdapter(adapter);
            }
            else if (!value.isEmpty())
                Toast.makeText(MainActivity.this, value, Toast.LENGTH_SHORT).show();
        }
    }
}