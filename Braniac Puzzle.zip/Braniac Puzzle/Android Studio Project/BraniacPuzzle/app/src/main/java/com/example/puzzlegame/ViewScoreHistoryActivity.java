package com.example.puzzlegame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewScoreHistoryActivity extends AppCompatActivity implements View.OnClickListener
{
    private WebView webScoreHistory;
    private Button btnBack;

    @Override
    protected void onCreate ( final Bundle savedInstanceState )
    {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_view_score_history );

        webScoreHistory = findViewById ( R.id.webScoreHistory );

        final WebSettings webSettings = webScoreHistory.getSettings();
        webSettings.setJavaScriptEnabled ( true );

        final WebViewClientImpl webViewClient = new WebViewClientImpl(this);
        webScoreHistory.setWebViewClient ( webViewClient );

        new PerformLoadScoreHistoryTask().execute();

        btnBack = findViewById ( R.id.btnBack );
        btnBack.setOnClickListener ( this );
    }

    private class WebViewClientImpl extends WebViewClient
    {
        private Activity activity = null;

        public WebViewClientImpl ( final Activity activity )
        {
            this.activity = activity;
        }

        @Override
        public boolean shouldOverrideUrlLoading ( final WebView webView, final String url )
        {
            return false;
        }
    }

    @Override
    public void onClick ( final View view )
    {
        switch ( view.getId() )
        {
            case R.id.btnBack:
                finish();
                break;
        }
    }

    private class PerformLoadScoreHistoryTask extends AsyncTask<Void, Void, String>
    {
        private String content;

        @Override
        protected String doInBackground ( Void... params )
        {
            content = "";

            Database.InitDatabase();

            String retval;

            try
            {
                Database.OpenDatabase();

                String sql = "SELECT to_char(\"Timestamp\",'FMDD/MM/YYYY'),to_char(\"Timestamp\",'HH24:MI:SS'),\"Puzzle ID\",\"Score\" FROM \"Score History\" ORDER BY \"Timestamp\" DESC,\"Score\" DESC";

                PreparedStatement ps = Database.GetPreparedStatement ( sql );

                ResultSet rs = ps.executeQuery();

                content = "<html>";
                content += "<body>";
                content += "<table>";
                content += "<tr>";
                content += "<th>No</th>";
                content += "<th>Date</th>";
                content += "<th>Time</th>";
                content += "<th>Puzzle ID</th>";
                content += "<th>Score</th>";
                content += "</tr>";

                int no = 1;

                while ( rs.next() )
                {
                    final String date = rs.getString ( 1 );
                    final String time = rs.getString ( 2 );
                    final int puzzleID = rs.getInt ( 3 );
                    final int score = rs.getInt ( 4 );

                    content += "<tr align='center'>";
                    content += "<td>" + no++ + "</td>";
                    content += "<td>" + date + "</td>";
                    content += "<td>" + time + "</td>";
                    content += "<td>" + puzzleID + "</td>";
                    content += "<td>" + score + "</td>";
                    content += "</tr>";
                }

                content += "</table>";

                content += "</body>";
                content += "</html>";

                rs.close();
                ps.close();
                Database.CloseDatabase();

                retval = "Success";
            }
            catch ( SQLException e )
            {
                e.printStackTrace();
                retval = e.toString();
            }

            return retval;
        }

        @Override
        protected void onPostExecute ( String value )
        {
            if ( value.equals("Success"))
            {
                webScoreHistory.loadData ( content, "text/html", "UTF-8" );
            }
            else
                Toast.makeText ( ViewScoreHistoryActivity.this, value, Toast.LENGTH_SHORT ).show();
        }
    }
}