package com.example.puzzlegame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

public class GameActivity extends AppCompatActivity implements View.OnClickListener
{
    private TextView txtPuzzleTitle;
    private ImageView imgPuzzleTopLeft, imgPuzzleTopRight, imgPuzzleBottomLeft, imgPuzzleBottomRight;
    private ImageView imgPuzzle1, imgPuzzle2, imgPuzzle3;
    private RadioButton radioPuzzle1, radioPuzzle2, radioPuzzle3;
    private Button btnBack;

    private int puzzleID;
    private String puzzleTitle, puzzleDescription;
    private final Bitmap[] bmpPuzzles = new Bitmap [ 4 ];
    private final boolean[] isPuzzleAssigned = new boolean[] { false, false, false, false };
    private int assignCount = 0;

    private int halfPuzzleWidth, halfPuzzleHeight;

    private int fixedImageIndex;
    private final int[] guessImageIndices = new int [ 3 ];
    private final int[] guessAngles = new int [ 3 ];
    private final boolean[] isPositionCorrect = new boolean[] { false, false, false };

    private final HashMap<Integer, Integer> hashGuessIndices = new HashMap<>();

    private int selectedPuzzle = -1;

    private final Matrix matrixPuzzle1 = new Matrix();
    private final Matrix matrixPuzzle2 = new Matrix();
    private final Matrix matrixPuzzle3 = new Matrix();

    private final float IMAGE_SCALE = 1.15f;

    private final String[][] arrQuestions = new String[][]
            {
                    { "What is the value of 3 + 9?", "What is the value of 12 - 7?" },
                    { "What is the value of 9 x 3?", "What is the value of 27 / 9?" },
                    { "What is the value of 2 + 3 + 4?", "What is the value of 5 - 3 + 2?", "What is the value of 4 x 3 x 2?", "What is the value of 12 x 2 / 3?" }
            };

    private final String[][][] arrAnswers = new String[][][]
            {
                    { { "10", "11", "12", "13" }, { "4","5","6","7" } },
                    { { "27","28","29", "30" }, { "2", "5", "4", "3" } },
                    { { "9", "8", "7", "6" }, { "7", "6", "5", "4" }, { "22", "24", "26", "28" }, { "6", "7", "8", "9" } }
            };

    private final int[][] arrCorrectAnswers = new int[][]
            {
                    { 3, 2 },
                    { 1, 4 },
                    { 1, 4, 2, 3 }
            };

    private int numberOfCorrectAnswers;
    private int numberOfTries;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        final Intent intent = getIntent();
        puzzleID = intent.getIntExtra("puzzleID", 0);
        puzzleTitle = intent.getStringExtra("puzzleTitle");
        final long oidPuzzleImage = intent.getLongExtra("oidPuzzleImage", 0L);
        puzzleDescription = intent.getStringExtra("puzzleDescription");

        numberOfCorrectAnswers = 0;
        numberOfTries = 0;

        final Bitmap bmpPuzzle = GlobalData.hashOidPuzzleImage.get ( oidPuzzleImage );
        halfPuzzleWidth = bmpPuzzle.getWidth() / 2; halfPuzzleHeight = bmpPuzzle.getHeight() / 2;

        bmpPuzzles [ 0 ] = Bitmap.createBitmap ( bmpPuzzle, 0, 0, halfPuzzleWidth, halfPuzzleHeight);
        bmpPuzzles [ 1 ] = Bitmap.createBitmap ( bmpPuzzle, halfPuzzleWidth, 0, halfPuzzleWidth, halfPuzzleHeight);
        bmpPuzzles [ 2 ] = Bitmap.createBitmap ( bmpPuzzle, 0, halfPuzzleHeight, halfPuzzleWidth, halfPuzzleHeight);
        bmpPuzzles [ 3 ] = Bitmap.createBitmap ( bmpPuzzle, halfPuzzleWidth, halfPuzzleHeight, halfPuzzleWidth, halfPuzzleHeight);

        final Random random = new Random();
        fixedImageIndex = random.nextInt(4);

        txtPuzzleTitle = findViewById(R.id.txtPuzzleTitle);
        txtPuzzleTitle.setText ( puzzleTitle );

        imgPuzzleTopLeft = findViewById(R.id.imgPuzzleTopLeft);
        imgPuzzleTopRight = findViewById(R.id.imgPuzzleTopRight);
        imgPuzzleBottomLeft = findViewById(R.id.imgPuzzleBottomLeft);
        imgPuzzleBottomRight = findViewById(R.id.imgPuzzleBottomRight);

        final ArrayList<Integer> alGuessImageIndices = new ArrayList<>();

        for ( int puzzleIndex = 0; puzzleIndex < bmpPuzzles.length; ++puzzleIndex )
            if ( puzzleIndex != fixedImageIndex )
                alGuessImageIndices.add ( puzzleIndex );

        Collections.shuffle ( alGuessImageIndices );

        for ( int guessIndex = 0; guessIndex < guessImageIndices.length; ++guessIndex )
        {
            guessImageIndices[guessIndex] = alGuessImageIndices.get(guessIndex);
            guessAngles[guessIndex] = random.nextInt(4) * 90;
        }

        imgPuzzleTopLeft.setScaleType ( ImageView.ScaleType.MATRIX );
        imgPuzzleTopRight.setScaleType ( ImageView.ScaleType.MATRIX );
        imgPuzzleBottomLeft.setScaleType ( ImageView.ScaleType.MATRIX );
        imgPuzzleBottomRight.setScaleType ( ImageView.ScaleType.MATRIX );

        final Matrix matrixPuzzle = new Matrix();
        matrixPuzzle.postRotate ( 0, halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
        matrixPuzzle.postScale ( IMAGE_SCALE, IMAGE_SCALE );

        imgPuzzleTopLeft.setImageMatrix ( matrixPuzzle );
        imgPuzzleTopRight.setImageMatrix ( matrixPuzzle );
        imgPuzzleBottomLeft.setImageMatrix ( matrixPuzzle );
        imgPuzzleBottomRight.setImageMatrix ( matrixPuzzle );

        isPuzzleAssigned [ fixedImageIndex ] = true;
        assignCount = 1;

        switch ( fixedImageIndex )
        {
            case 0:
                hashGuessIndices.put ( 1, 0 );
                hashGuessIndices.put ( 2, 1 );
                hashGuessIndices.put ( 3, 2 );

                imgPuzzleTopLeft.setImageBitmap ( bmpPuzzles [ 0 ] );
                imgPuzzleTopRight.setOnClickListener(this);
                imgPuzzleBottomLeft.setOnClickListener(this);
                imgPuzzleBottomRight.setOnClickListener(this);
                break;

            case 1:
                hashGuessIndices.put ( 0, 0 );
                hashGuessIndices.put ( 2, 1 );
                hashGuessIndices.put ( 3, 2 );

                imgPuzzleTopLeft.setOnClickListener(this);
                imgPuzzleTopRight.setImageBitmap ( bmpPuzzles [ 1 ] );
                imgPuzzleBottomLeft.setOnClickListener(this);
                imgPuzzleBottomRight.setOnClickListener(this);
                break;

            case 2:
                hashGuessIndices.put ( 0, 0 );
                hashGuessIndices.put ( 1, 1 );
                hashGuessIndices.put ( 3, 2 );

                imgPuzzleTopLeft.setOnClickListener(this);
                imgPuzzleTopRight.setOnClickListener(this);
                imgPuzzleBottomLeft.setImageBitmap ( bmpPuzzles [ 2 ] );
                imgPuzzleBottomRight.setOnClickListener(this);
                break;

            case 3:
                hashGuessIndices.put ( 0, 0 );
                hashGuessIndices.put ( 1, 1 );
                hashGuessIndices.put ( 2, 2 );

                imgPuzzleTopLeft.setOnClickListener(this);
                imgPuzzleTopRight.setOnClickListener(this);
                imgPuzzleBottomLeft.setOnClickListener(this);
                imgPuzzleBottomRight.setImageBitmap ( bmpPuzzles [ 3 ] );
                break;
        }

        imgPuzzle1 = findViewById(R.id.imgPuzzle1);
        imgPuzzle2 = findViewById(R.id.imgPuzzle2);
        imgPuzzle3 = findViewById(R.id.imgPuzzle3);

        imgPuzzle1.setImageBitmap ( bmpPuzzles [ guessImageIndices [ 0 ] ] );
        imgPuzzle2.setImageBitmap ( bmpPuzzles [ guessImageIndices [ 1 ] ] );
        imgPuzzle3.setImageBitmap ( bmpPuzzles [ guessImageIndices [ 2 ] ] );

        imgPuzzle1.setScaleType ( ImageView.ScaleType.MATRIX );
        imgPuzzle2.setScaleType ( ImageView.ScaleType.MATRIX );
        imgPuzzle3.setScaleType ( ImageView.ScaleType.MATRIX );

        matrixPuzzle1.postRotate ( guessAngles [ 0 ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
        matrixPuzzle2.postRotate ( guessAngles [ 1 ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
        matrixPuzzle3.postRotate ( guessAngles [ 2 ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );

        imgPuzzle1.setImageMatrix ( matrixPuzzle1 );
        imgPuzzle2.setImageMatrix ( matrixPuzzle2 );
        imgPuzzle3.setImageMatrix ( matrixPuzzle3 );

        imgPuzzle1.setOnClickListener(this);
        imgPuzzle2.setOnClickListener(this);
        imgPuzzle3.setOnClickListener(this);

        radioPuzzle1 = findViewById(R.id.radioPuzzle1);
        radioPuzzle2 = findViewById(R.id.radioPuzzle2);
        radioPuzzle3 = findViewById(R.id.radioPuzzle3);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);
    }

    private void DisplayQuiz ( final int piece )
    {
        final String[] arrQuestion = arrQuestions [ piece - 1 ];
        final String[][] arrAnswer = arrAnswers [ piece - 1 ];
        final int[] arrCorrectAnswer = arrCorrectAnswers [ piece - 1 ];

        for ( int questionIndex = arrQuestion.length - 1; questionIndex >= 0; --questionIndex )
        {
            final int questionNumber = questionIndex + 1;
            final String question = arrQuestion [ questionIndex ];
            final String[] answers = arrAnswer [ questionIndex ];
            final int correctAnswer = arrCorrectAnswer [ questionIndex ];

            final AlertDialog.Builder builder = new AlertDialog.Builder ( this );
            final ViewGroup viewGroup = findViewById ( android.R.id.content );
            final View dialogView = LayoutInflater.from ( GameActivity.this ).inflate ( R.layout.layout_quiz_dialog, viewGroup, false );

            builder.setView ( dialogView );

            final AlertDialog alertDialog = builder.create();
            alertDialog.setCancelable ( false );

            final TextView txtTitle = dialogView.findViewById ( R.id.txtTitle );
            final TextView txtQuestionNumber = dialogView.findViewById ( R.id.txtQuestionNumber );
            final TextView txtQuestion = dialogView.findViewById ( R.id.txtQuestion );

            txtTitle.setText ( "Quiz for Puzzle Piece #" + piece + " Placement" );
            txtQuestionNumber.setText ( "Question " + questionNumber );
            txtQuestion.setText ( question );

            final RadioButton radioAnswerA = dialogView.findViewById ( R.id.radioAnswerA );
            final RadioButton radioAnswerB = dialogView.findViewById ( R.id.radioAnswerB );
            final RadioButton radioAnswerC = dialogView.findViewById ( R.id.radioAnswerC );
            final RadioButton radioAnswerD = dialogView.findViewById ( R.id.radioAnswerD );

            radioAnswerA.setText ( answers [ 0 ] );
            radioAnswerB.setText ( answers [ 1 ] );
            radioAnswerC.setText ( answers [ 2 ] );
            radioAnswerD.setText ( answers [ 3 ] );

            final Button btnSubmitAnswer = dialogView.findViewById ( R.id.btnSubmitAnswer );

            btnSubmitAnswer.setOnClickListener ( new View.OnClickListener()
            {
                @Override
                public void onClick ( final View view )
                {
                    int answer = 0;

                    if ( radioAnswerA.isChecked() )
                        answer = 1;
                    else if ( radioAnswerB.isChecked() )
                        answer = 2;
                    else if ( radioAnswerC.isChecked() )
                        answer = 3;
                    else if ( radioAnswerD.isChecked() )
                        answer = 4;

                    if ( answer == 0 )
                    {
                        Toast.makeText ( GameActivity.this, "Please select an answer!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if ( answer == correctAnswer )
                    {
                        ++numberOfCorrectAnswers;
                        Toast.makeText(GameActivity.this, "Answer is correct!", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText ( GameActivity.this, "Wrong answer!", Toast.LENGTH_SHORT).show();

                    alertDialog.dismiss();
                }
            } );

            alertDialog.show();
        }
    }

    @Override
    public void onClick ( final View view )
    {
        int guessPosition;
        boolean isAllPositionsCorrect, isAllAnglesCorrect;
        Matrix matrixPuzzle;

        switch ( view.getId() )
        {
            case R.id.imgPuzzleTopLeft:
                if ( selectedPuzzle == -1 )
                {
                    Toast.makeText(this, "Please select a puzzle piece first!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !isPuzzleAssigned [ 0 ] )
                {
                    DisplayQuiz ( assignCount++ );
                }

                guessPosition = hashGuessIndices.get ( 0 );
                isPositionCorrect [ guessPosition ] = ( guessImageIndices [ selectedPuzzle ] == 0 );

                imgPuzzleTopLeft.setImageBitmap ( bmpPuzzles [ guessImageIndices [ selectedPuzzle ] ] );

                matrixPuzzle = new Matrix();
                matrixPuzzle.postRotate ( guessAngles [ selectedPuzzle ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                matrixPuzzle.postScale ( IMAGE_SCALE, IMAGE_SCALE );
                imgPuzzleTopLeft.setImageMatrix ( matrixPuzzle );

                isPuzzleAssigned [ 0 ] = true;
                ++numberOfTries;

                isAllPositionsCorrect = true;

                for ( boolean positionCorrect : isPositionCorrect )
                {
                    if ( !positionCorrect )
                    {
                        isAllPositionsCorrect = false;
                        break;
                    }
                }

                isAllAnglesCorrect = true;

                for ( int angle : guessAngles )
                {
                    if ( angle != 0 )
                    {
                        isAllAnglesCorrect = false;
                        break;
                    }
                }

                if ( isAllPositionsCorrect && isAllAnglesCorrect )
                {
                    int score = numberOfCorrectAnswers - ( numberOfTries - 3 );

                    if ( score < 0 )
                        score = 0;

                    new SaveScoreTask().execute ( puzzleID, score );

                    DisplayAlert("Congratulations... you have all the positions correct!\n\nNumber of correct answers: " + numberOfCorrectAnswers + "\nNumber of tries: " + numberOfTries + "\nScore: " + score, "Congratulations!");
                }

                break;

            case R.id.imgPuzzleTopRight:
                if ( selectedPuzzle == -1 )
                {
                    Toast.makeText(this, "Please select a puzzle piece first!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !isPuzzleAssigned [ 1 ] )
                {
                    DisplayQuiz ( assignCount++ );
                }

                guessPosition = hashGuessIndices.get ( 1 );
                isPositionCorrect [ guessPosition ] = ( guessImageIndices [ selectedPuzzle ] == 1 );

                imgPuzzleTopRight.setImageBitmap ( bmpPuzzles [ guessImageIndices [ selectedPuzzle ] ] );

                matrixPuzzle = new Matrix();
                matrixPuzzle.postRotate ( guessAngles [ selectedPuzzle ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                matrixPuzzle.postScale ( IMAGE_SCALE, IMAGE_SCALE );
                imgPuzzleTopRight.setImageMatrix ( matrixPuzzle );

                isPuzzleAssigned [ 1 ] = true;
                ++numberOfTries;

                isAllPositionsCorrect = true;

                for ( boolean positionCorrect : isPositionCorrect )
                {
                    if ( !positionCorrect )
                    {
                        isAllPositionsCorrect = false;
                        break;
                    }
                }

                isAllAnglesCorrect = true;

                for ( int angle : guessAngles )
                {
                    if ( angle != 0 )
                    {
                        isAllAnglesCorrect = false;
                        break;
                    }
                }

                if ( isAllPositionsCorrect && isAllAnglesCorrect )
                {
                    int score = numberOfCorrectAnswers - ( numberOfTries - 3 );

                    if ( score < 0 )
                        score = 0;

                    new SaveScoreTask().execute ( puzzleID, score );

                    DisplayAlert("Congratulations... you have all the positions correct!\n\nNumber of correct answers: " + numberOfCorrectAnswers + "\nNumber of tries: " + numberOfTries + "\nScore: " + score, "Congratulations!");
                }

                break;

            case R.id.imgPuzzleBottomLeft:
                if ( selectedPuzzle == -1 )
                {
                    Toast.makeText(this, "Please select a puzzle piece first!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !isPuzzleAssigned [ 2 ] )
                {
                    DisplayQuiz ( assignCount++ );
                }

                guessPosition = hashGuessIndices.get ( 2 );
                isPositionCorrect [ guessPosition ] = ( guessImageIndices [ selectedPuzzle ] == 2 );

                imgPuzzleBottomLeft.setImageBitmap ( bmpPuzzles [ guessImageIndices [ selectedPuzzle ] ] );

                matrixPuzzle = new Matrix();
                matrixPuzzle.postRotate ( guessAngles [ selectedPuzzle ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                matrixPuzzle.postScale ( IMAGE_SCALE, IMAGE_SCALE );
                imgPuzzleBottomLeft.setImageMatrix ( matrixPuzzle );

                isPuzzleAssigned [ 2 ] = true;
                ++numberOfTries;

                isAllPositionsCorrect = true;

                for ( boolean positionCorrect : isPositionCorrect )
                {
                    if ( !positionCorrect )
                    {
                        isAllPositionsCorrect = false;
                        break;
                    }
                }

                isAllAnglesCorrect = true;

                for ( int angle : guessAngles )
                {
                    if ( angle != 0 )
                    {
                        isAllAnglesCorrect = false;
                        break;
                    }
                }

                if ( isAllPositionsCorrect && isAllAnglesCorrect )
                {
                    int score = numberOfCorrectAnswers - ( numberOfTries - 3 );

                    if ( score < 0 )
                        score = 0;

                    new SaveScoreTask().execute ( puzzleID, score );

                    DisplayAlert("Congratulations... you have all the positions correct!\n\nNumber of correct answers: " + numberOfCorrectAnswers + "\nNumber of tries: " + numberOfTries + "\nScore: " + score, "Congratulations!");
                }

                break;

            case R.id.imgPuzzleBottomRight:
                if ( selectedPuzzle == -1 )
                {
                    Toast.makeText(this, "Please select a puzzle piece first!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( !isPuzzleAssigned [ 3 ] )
                {
                    DisplayQuiz ( assignCount++ );
                }

                guessPosition = hashGuessIndices.get ( 3 );
                isPositionCorrect [ guessPosition ] = ( guessImageIndices [ selectedPuzzle ] == 3 );

                imgPuzzleBottomRight.setImageBitmap ( bmpPuzzles [ guessImageIndices [ selectedPuzzle ] ] );

                matrixPuzzle = new Matrix();
                matrixPuzzle.postRotate ( guessAngles [ selectedPuzzle ], halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                matrixPuzzle.postScale ( IMAGE_SCALE, IMAGE_SCALE );
                imgPuzzleBottomRight.setImageMatrix ( matrixPuzzle );

                isPuzzleAssigned [ 3 ] = true;
                ++numberOfTries;

                isAllPositionsCorrect = true;

                for ( boolean positionCorrect : isPositionCorrect )
                {
                    if ( !positionCorrect )
                    {
                        isAllPositionsCorrect = false;
                        break;
                    }
                }

                isAllAnglesCorrect = true;

                for ( int angle : guessAngles )
                {
                    if ( angle != 0 )
                    {
                        isAllAnglesCorrect = false;
                        break;
                    }
                }

                if ( isAllPositionsCorrect && isAllAnglesCorrect )
                {
                    int score = numberOfCorrectAnswers - ( numberOfTries - 3 );

                    if ( score < 0 )
                        score = 0;

                    new SaveScoreTask().execute ( puzzleID, score );

                    DisplayAlert("Congratulations... you have all the positions correct!\n\nNumber of correct answers: " + numberOfCorrectAnswers + "\nNumber of tries: " + numberOfTries + "\nScore: " + score, "Congratulations!");
                }

                break;

            case R.id.imgPuzzle1:
                if ( !radioPuzzle1.isChecked() )
                {
                    selectedPuzzle = 0;
                    radioPuzzle1.setChecked(true);
                    radioPuzzle2.setChecked(false);
                    radioPuzzle3.setChecked(false);
                }
                else
                {
                    guessAngles [ 0 ] = ( guessAngles [ 0 ] + 90 ) % 360;
                    matrixPuzzle1.postRotate ( 90, halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                    imgPuzzle1.setImageMatrix ( matrixPuzzle1 );
                }
                break;

            case R.id.imgPuzzle2:
                if ( !radioPuzzle2.isChecked() )
                {
                    selectedPuzzle = 1;
                    radioPuzzle1.setChecked(false);
                    radioPuzzle2.setChecked(true);
                    radioPuzzle3.setChecked(false);
                }
                else
                {
                    guessAngles [ 1 ] = ( guessAngles [ 1 ] + 90 ) % 360;
                    matrixPuzzle2.postRotate ( 90, halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                    imgPuzzle2.setImageMatrix ( matrixPuzzle2 );
                }
                break;

            case R.id.imgPuzzle3:
                if ( !radioPuzzle3.isChecked() )
                {
                    selectedPuzzle = 2;
                    radioPuzzle1.setChecked(false);
                    radioPuzzle2.setChecked(false);
                    radioPuzzle3.setChecked(true);
                }
                else
                {
                    guessAngles [ 2 ] = ( guessAngles [ 2 ] + 90 ) % 360;
                    matrixPuzzle3.postRotate ( 90, halfPuzzleWidth / 2, halfPuzzleHeight / 2 );
                    imgPuzzle3.setImageMatrix ( matrixPuzzle3 );
                }
                break;

            case R.id.btnBack:
                finish();
                break;
        }
    }

    private class SaveScoreTask extends AsyncTask<Integer, Void, String>
    {
        @Override
        protected String doInBackground ( Integer... params )
        {
            final int puzzleID = params [ 0 ];
            final int score = params [ 1 ];

            Database.InitDatabase();

            String retval;

            try
            {
                Database.OpenDatabase();

                PreparedStatement ps = Database.GetPreparedStatement("INSERT INTO \"Score History\" (\"Timestamp\",\"Puzzle ID\",\"Score\") VALUES (NOW(),?,?)");
                ps.setInt ( 1, puzzleID );
                ps.setInt ( 2, score );

                ps.executeUpdate();

                Database.Commit();

                ps.close();

                Database.CloseDatabase();

                retval = "Success";
            }
            catch ( SQLException e )
            {
                e.printStackTrace();
                retval = e.toString();
            }

            return retval;
        }

        @Override
        protected void onPostExecute ( String value )
        {
            if (value.equals("Success"))
            {
                Toast.makeText ( GameActivity.this, "Score saved successfully to database!", Toast.LENGTH_SHORT).show();
            }
            else if (!value.isEmpty())
                Toast.makeText(GameActivity.this, value, Toast.LENGTH_SHORT).show();
        }
    }

    private void DisplayAlert ( final String message, final String title )
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder ( this );

        builder.setTitle ( title );
        builder.setMessage ( message )
            .setCancelable ( false )
            .setPositiveButton ( "OK", new DialogInterface.OnClickListener()
            {
                public void onClick ( final DialogInterface dialog, final int id )
                {
                    finish();
                }
             } );

        final AlertDialog alert = builder.create();
        alert.show();
    }
}