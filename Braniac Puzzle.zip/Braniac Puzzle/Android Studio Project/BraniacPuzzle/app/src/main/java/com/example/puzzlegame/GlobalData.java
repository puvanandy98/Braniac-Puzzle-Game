package com.example.puzzlegame;

import android.graphics.Bitmap;

import java.util.HashMap;

public class GlobalData
{
    public static HashMap<Long, Bitmap> hashOidPuzzleImage = new HashMap<>();
}
