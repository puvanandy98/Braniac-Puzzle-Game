package com.example.puzzlegame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StartActivity extends AppCompatActivity implements View.OnClickListener
{
    private EditText editServerAddress, editUsername, editPassword;
    private Button btnLogin, btnClear, btnQuit;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        editServerAddress = findViewById(R.id.editServerAddress);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        editServerAddress.setText ( Database.getServerAddress() );

        btnLogin = findViewById(R.id.btnLogin);
        btnClear = findViewById(R.id.btnClear);
        btnQuit = findViewById(R.id.btnQuit);

        btnLogin.setOnClickListener(this);
        btnClear.setOnClickListener(this);
        btnQuit.setOnClickListener(this);
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.btnLogin:
                final String serverAddress = editServerAddress.getText().toString().trim();

                if ( serverAddress.isEmpty() )
                {
                    Toast.makeText ( this, "Please enter server address!", Toast.LENGTH_SHORT ).show();
                    return;
                }

                final String username = editUsername.getText().toString().trim();

                if ( username.isEmpty() )
                {
                    Toast.makeText ( this, "Please enter username!", Toast.LENGTH_SHORT ).show();
                    return;
                }

                final String password = editPassword.getText().toString().trim();

                if ( password.isEmpty() )
                {
                    Toast.makeText ( this, "Please enter password!", Toast.LENGTH_SHORT ).show();
                    return;
                }

                Database.setServerAddress ( serverAddress );

                new PerformLoginTask().execute ( username, password );
                break;

            case R.id.btnClear:
                editUsername.setText("");
                editPassword.setText("");
                break;

            case R.id.btnQuit:
                finish();
                break;
        }
    }

    private class PerformLoginTask extends AsyncTask<String, Void, String>
    {
        @Override
        protected String doInBackground ( String... params )
        {
            String username = params[0];
            String password = params[1];

            Database.InitDatabase();

            String retval;

            try
            {
                Database.OpenDatabase();

                String sql = "SELECT COUNT(*) FROM \"User Profile\" WHERE \"Username\"=? AND \"Password\"=?";

                PreparedStatement ps = Database.GetPreparedStatement(sql);
                ps.setString(1, username);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();

                rs.next();

                retval = ( rs.getLong ( 1 ) == 1 ) ? "Success" : "Invalid";

                rs.close();
                ps.close();
                Database.CloseDatabase();
            }
            catch ( SQLException e )
            {
                e.printStackTrace();
                retval = e.toString();
            }

            return retval;
        }

        @Override
        protected void onPostExecute ( String value )
        {
            if ( value.equals("Success"))
            {
                editPassword.setText("");

                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                StartActivity.this.startActivity(intent);
            }
            else if ( value.equals("Invalid"))
            {
                Toast.makeText ( StartActivity.this, "Invalid username and/or password!", Toast.LENGTH_SHORT ).show();
                editPassword.setText("");
            }
            else
                Toast.makeText ( StartActivity.this, value, Toast.LENGTH_SHORT ).show();
        }
    }
}